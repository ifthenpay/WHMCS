<?php

namespace WHMCS\Module\Gateway\Ifthenpay\Exceptions;

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

class IfthenpayInvoiceUpdateException extends \Exception
{
}